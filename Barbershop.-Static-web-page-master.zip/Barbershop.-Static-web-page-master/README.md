# Barbershop.-Static-web-page
This project was created to apply knowledge of HTML and CSS such as: creating text, images, blocks of content, lists of information, changing color, positioning elements and changing spacing.


![Barber-nativos-(gif)](https://user-images.githubusercontent.com/38620899/93786343-96027180-fc05-11ea-87a8-3b82c4adeb37.gif)
